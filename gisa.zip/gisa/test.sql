select count(*) from gisa;

select sum((kor+
(case
	when loc_code = 'A' then 5
	when loc_code = 'B' then 10
	when loc_code = 'C' then 15
end)
)>=50) answer
from gisa
where acc_code = 'A' or acc_code = 'B';