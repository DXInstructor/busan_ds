package busan.hadoop.sqoop;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class GisaMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	
	@Override
	protected void map(LongWritable key, Text value, 
			Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		GisaParser parser = new GisaParser(value);
		
//		String keyText = "locB";
//		int outputValue = 0;
//		
//		if(parser.getLocCode().equals("B")) {
//			outputValue = parser.getMaxScore();
//			context.write(new Text(keyText), new IntWritable(outputValue));
//		}	
		
		if(parser.getAccCode().equals("A")||parser.getAccCode().equals("B")) {
			String keyText = "accA_B";
			int val = parser.getKor()+parser.getPointOfNum4();
			context.write(new Text(keyText), new IntWritable(val));
		}
	}
	
}
