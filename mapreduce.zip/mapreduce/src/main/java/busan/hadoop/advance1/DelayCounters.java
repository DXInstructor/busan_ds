package busan.hadoop.advance1;

public enum DelayCounters {
  not_available_arrival, scheduled_arrival, early_arrival, not_available_departure,
  scheduled_departure, early_departure;
}
