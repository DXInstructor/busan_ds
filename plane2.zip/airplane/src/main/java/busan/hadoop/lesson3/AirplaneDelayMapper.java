package busan.hadoop.lesson3;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class AirplaneDelayMapper extends Mapper<LongWritable, Text, Text, IntWritable>{
	private String workType;
	
	@Override
	protected void setup(Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		workType = context.getConfiguration().get("workType");
	}
	//-D workType=arrival data/input data/output
	@Override
	protected void map(LongWritable key, Text value, 
				Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		// 각 년도에 도착지연의 횟수 카운팅 --> 맵 
		AirplaneDelayParser parser = new AirplaneDelayParser(value);
		
		if(workType.equals("arrival")) {
			if(parser.isUseArrivalInfo()&&parser.getArrivalDelay()>0) {
				//도착지연이 확인되어져야 한다.
				String temp = parser.getMonth();
				//temp = temp.length()==1?"0"+temp:temp;
				if(temp.length()==1) {
					temp = "0"+temp;
				} 
				context.write(new Text(parser.getYear()+","+temp), new IntWritable(1));
			}
		} else if(workType.equals("departure")) {
			if(parser.isUseDepartureInfo()&&parser.getDepartureDelay()>0) {
				//도착지연이 확인되어져야 한다.
				String temp = parser.getMonth();
				//temp = temp.length()==1?"0"+temp:temp;
				if(temp.length()==1) {
					temp = "0"+temp;
				} 
				context.write(new Text(parser.getYear()+","+temp), new IntWritable(1));
			}
		}
	}
}
