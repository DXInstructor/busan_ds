package busan.hadoop.lesson3;

import org.apache.hadoop.io.Text;

public class AirplaneDelayParser {
	private String year;
	private String month;
	
	private int arrivalDelay;
	private int departureDelay;
	private int distance;
	
	private boolean isUseArrivalInfo;
	private boolean isUseDepartureInfo;
	private boolean isUseDistanceInfo;
	
	public AirplaneDelayParser(Text text) {
		this.parse(text.toString());
	}

	private void parse(String line) {//해당 라인은 ,로 구분되어져 있는 정보
		// TODO Auto-generated method stub
		String[] temp = line.split(",");
		year = temp[0];
		month = temp[1];
		
		if(!temp[14].equals("NA")&&!Character.isAlphabetic(temp[14].charAt(0))/*정수형변환 예외사항처리*/) {
			this.isUseArrivalInfo = true;
			this.arrivalDelay = Integer.parseInt(temp[14]);
		}
		
		if(!temp[15].equals("NA")&&!Character.isAlphabetic(temp[15].charAt(0))) {
			this.isUseDepartureInfo = true;
			this.departureDelay = Integer.parseInt(temp[15]);
		}
		
		if(!temp[18].equals("NA")&&!Character.isAlphabetic(temp[18].charAt(0))) {
			this.isUseDistanceInfo = true;
			this.distance = Integer.parseInt(temp[18]);
		}
	}

	public String getYear() {
		return year;
	}

	public String getMonth() {
		return month;
	}

	public int getArrivalDelay() {
		return arrivalDelay;
	}

	public int getDepartureDelay() {
		return departureDelay;
	}

	public int getDistance() {
		return distance;
	}

	public boolean isUseArrivalInfo() {
		return isUseArrivalInfo;
	}

	public boolean isUseDepartureInfo() {
		return isUseDepartureInfo;
	}

	public boolean isUseDistanceInfo() {
		return isUseDistanceInfo;
	}
	
	
}
