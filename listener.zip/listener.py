from pyspark.sql import SparkSession
from pyspark import SparkContext
from pyspark.streaming import StreamingContext


def listening():
	#spark = SparkSession.builder.getOrCreate()
	sc = SparkContext(appName="test")
	ssc = StreamingContext(sc,6)
	lines = ssc.textFileStream("/home/ds/dev/input")
	counts = lines.flatMap(lambda line : line.split(" "))\
    	.map(lambda x : (x , 1) )\
    	.reduceByKey(lambda a, b : a+b)
	counts.pprint()
	counts.saveAsTextFiles("/home/ds/dev/output/txt_data", "txt")
	ssc.start()
	status = ssc.awaitTerminationOrTimeout(60)
	print(status)
	if not status:
    		sc._jvm.StreamingContext.getActive().get().stop(False)


if __name__ == "__main__":
	listening()
	
