package busan.hadoop.sqoop;

import org.apache.hadoop.io.Text;

public class GisaParser {
	private int maxScore;
	private int kor;
	private int eng;
	
	private String locCode;
	
	public GisaParser(Text text) {
		this.parse(text.toString());
	}

	private void parse(String string) {
		// TODO Auto-generated method stub
		String[] temp = string.split(",");
		kor = Integer.parseInt(temp[1]);
		eng = Integer.parseInt(temp[2]);
		maxScore = kor+eng;
		locCode = temp[10];
	}

	public int getMaxScore() {
		return maxScore;
	}

	public String getLocCode() {
		return locCode;
	}
	
}
