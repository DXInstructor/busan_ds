package busan.hadoop.sqoop2;



import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupKeyComparator extends WritableComparator {

  protected GroupKeyComparator() {
    super(CompositeKey.class, true);
  }

  @SuppressWarnings("rawtypes")
  @Override
  public int compare(WritableComparable w1, WritableComparable w2) {
    CompositeKey k1 = (CompositeKey) w1;
    CompositeKey k2 = (CompositeKey) w2;

    //연도값 비교
    return k1.getStdNo().compareTo(k2.getStdNo());
  }
}
