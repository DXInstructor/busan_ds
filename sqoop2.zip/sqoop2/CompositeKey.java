package busan.hadoop.sqoop2;



import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableUtils;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class CompositeKey implements WritableComparable<CompositeKey> {

  private String stdNo;
  private Integer score;

  public CompositeKey() {
  }

  public CompositeKey(String stdNo, Integer score) {
    this.stdNo = stdNo;
    this.score = score;
  }

  

  public String getStdNo() {
	return stdNo;
  }

//  public void setStdNo(String stdNo) {
//	this.stdNo = stdNo;
//  }

  public Integer getScore() {
	return score;
  }

//  public void setScore(Integer score) {
//	this.score = score;
//  }

  public void readFields(DataInput in) throws IOException {
    stdNo = WritableUtils.readString(in);
    score = in.readInt();
  }


  public void write(DataOutput out) throws IOException {
    WritableUtils.writeString(out, stdNo);
    out.writeInt(score);
  }

 
  public int compareTo(CompositeKey key) {
    int result = key.score.compareTo(score);
    if (0 == result) {
      result = stdNo.compareTo(key.stdNo);
    }
    return result;
  }

	@Override
	public String toString() {
		return "[stdNo=" + stdNo + ", score=" + score + "]";
	}
}
