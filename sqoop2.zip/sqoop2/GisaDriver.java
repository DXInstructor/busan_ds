package busan.hadoop.sqoop2;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;


public class GisaDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration conf = new Configuration();
		try {
			Job job = new Job(conf, "gisa");
			job.setJarByClass(GisaDriver.class);
		    job.setPartitionerClass(GroupKeyPartitioner.class);
		    job.setGroupingComparatorClass(GroupKeyComparator.class);
		    job.setSortComparatorClass(CompositeKeyComparator.class);
			    
			job.setMapperClass(GisaMapper.class);
			job.setReducerClass(GisaReducer.class);
			
			FileInputFormat.addInputPath(job, new Path(args[0]));
			FileOutputFormat.setOutputPath(job, new Path(args[1]));
			
			job.setMapOutputKeyClass(CompositeKey.class);
			job.setMapOutputValueClass(IntWritable.class);
			
			job.setOutputKeyClass(CompositeKey.class);
			job.setOutputValueClass(IntWritable.class);
			
			
			   // 입출력 데이터 포맷 설정
		    job.setInputFormatClass(TextInputFormat.class);
		    job.setOutputFormatClass(TextOutputFormat.class);
		    
			job.waitForCompletion(true);
		
		} catch (IOException | ClassNotFoundException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
