package busan.hadoop.sqoop2;

import org.apache.hadoop.io.Text;

public class GisaParser {
	private int maxScore;
	private int kor;
	private int eng;
	private int pointOfNum4;
	String stdNo;
	private String locCode;
	private String accCode;
	
	public GisaParser(Text text) {
		pointOfNum4 = 5;
		this.parse(text.toString());
	}

	private void parse(String string) {
		// TODO Auto-generated method stub
		String[] temp = string.split(",");
		stdNo = temp[0];
		kor = Integer.parseInt(temp[2]);
		eng = Integer.parseInt(temp[3]);
		maxScore = kor+eng;
		accCode = temp[9];
		locCode = temp[10];
		if(locCode.equals("B")) {
			pointOfNum4 = 10;
		} else if(locCode.equals("C")){
			pointOfNum4 = 15;
		}
	}

	public int getMaxScore() {
		return maxScore;
	}

	public String getLocCode() {
		return locCode;
	}

	public String getAccCode() {
		return accCode;
	}

	public int getPointOfNum4() {
		return pointOfNum4;
	}

	public int getKor() {
		return kor;
	}

	public String getStdNo() {
		return stdNo;
	}
	
	
	
}
