package busan.hadoop.sqoop2;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class GisaReducer extends Reducer<CompositeKey,IntWritable, Text, IntWritable>{
	private int row;
	@Override
	protected void reduce(CompositeKey key, Iterable<IntWritable> values,
			Reducer<CompositeKey, IntWritable, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
//		int sum = 0;
//		for(IntWritable value : values) {
//			sum += 1;
//		}
//		context.write(new Text(key.toString()), new IntWritable(sum));
		row++;
		if(row==5) {
			System.out.println(key);
			context.write(new Text("answer"), new IntWritable(key.getScore()));
		}
	}
}
