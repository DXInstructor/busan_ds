package busan.hadoop.sqoop2;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class GisaMapper extends Mapper<LongWritable, Text, CompositeKey, IntWritable> {
	
	@Override
	protected void map(LongWritable key, Text value,
			Mapper<LongWritable, Text, CompositeKey, IntWritable>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		GisaParser parser = new GisaParser(value);
		CompositeKey ck = new CompositeKey(parser.getStdNo(), parser.getMaxScore());
		//System.out.println(ck);
		context.write(ck, new IntWritable(1));
	}
	
}
